Simpel chall ini wok!
Lu tinggal lempar ke LLM kyk ChatGPT pun auto solved ini!

Hint:
Ga usah hint la yaw? easy banget coy!.
Romawi, titik titik di matematika!
